import logging
import traceback
import boto3
import json
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # TODO implement
    logger.info('event: {}'.format(event))
    logger.info('context: {}'.format(context))
    response = {
        'statusCode': 200,
        'body': json.dumps('DNS Update Success!')
    }
    try:
        # Globals
        region = event['region']
        accountId = event['account']
        detailtype = event['detail-type']
        if detailtype == 'EC2 Instance State-change Notification':
            instanceid = event['detail']['instance-id']
            logger.info('Instance: {}'.format(instanceid))
            state = event['detail']['state']
            logger.info('State: {}'.format(state))
            if state == 'running':
                try:
                    client = boto3.client('ec2',region_name=region)
                    descinst = client.describe_instances(
                        InstanceIds=[
                            instanceid
                        ],
                        DryRun=False
                    )
                    for reservation in descinst['Reservations']:
                        for instance in reservation['Instances']:
                            MPrivIP=instance['PrivateIpAddress']
                            if 'PublicIpAddress' in instance:
                                MPubIP = instance['PublicIpAddress']
                            if 'Tags' in instance:
                                for tag in instance['Tags']:
                                    if tag['Key'] == 'Name':
                                        hostname = tag['Value']
                                    if tag['Key'] == 'HZ':
                                        hostedzones = tag['Value']
                            eniid=0
                            for eni in instance['NetworkInterfaces']:
                                if 'Ipv6Addresses' in eni:
                                    for ipv6 in eni['Ipv6Addresses']:
                                        if eniid == 0:
                                            MIPv6 = ipv6['Ipv6Address']
                                        if eniid != 0:
                                            PubIPV6[eniid] = ipv6['Ipv6Address']
                                if 'PrivateIpAddresses' in eni:
                                    for ipv4 in eni['PrivateIpAddresses']:
                                        if MPrivIP != ipv4['PrivateIpAddress']:
                                            PrivIPV4[eniid] = ipv4['PrivateIpAddress']
                                        if 'Association' in ipv4:
                                            if MPubIP != ipv4['Association']['PublicIp']:
                                                PubIPV4[eniid] = ipv4['Association']['PublicIp']
                                eniid=eniid+1
                except Exception as e:
                    print('ERROR: {}'.format(e))
                    traceback.print_exc()
                    return str(e)
                logger.info(
                    'Hostname: {0}\nMainPrivateIpAddress: {1}\nMainPublic IPv4: {2}\nMainPublic IPv6: {3}\nSecPublic IPv6: {4}\nSecPrivate IPv4: {5}\nSecPublic IPv4: {6}\nHosted Zone IDs: {7}\n'.format(
                        hostname, MPrivIP, MPubIP, MIPv6, PubIPV6, PrivIPV4, PubIPV4, hostedzones
                        )
                    )
        response = {}
        response["statusCode"] = "200"
        response["body"] = json.dumps('DNS Update Success!')
        print (response)
    except Exception as e:
        logger.error('ERROR: {}'.format(e))
        traceback.print_exc()
        response["statusCode"] = "500"
        macro_response["body"] = str(e)
    return response
