import logging
import traceback
import boto3
import json
logger = logging.getLogger()
logger.setLevel(logging.INFO)
hostname=''
MPrivIP=''
MPubIP=''
MIPv6=''
PubIPV6={}
PrivIPV4={}
PubIPV4={}
hostedzones=''

def ec2_desc(instanceid, region):
    # TODO implement
    try:
        client = boto3.client('ec2',region_name=region)
        descinst = client.describe_instances(
            InstanceIds=[
                instanceid
            ],
            DryRun=False
        )
        for reservation in descinst['Reservations']:
            for instance in reservation['Instances']:
                MPrivIP = instance['PrivateIpAddress']
                if 'PublicIpAddress' in instance:
                    MPubIP = instance['PublicIpAddress']
                else:
                    MPubIP = ''
                if 'Tags' in instance:
                    for tag in instance['Tags']:
                        if tag['Key'] == 'Name':
                            hostname = tag['Value']
                        if tag['Key'] == 'HZ':
                            hostedzones = tag['Value']
                        else:
                            hostedzones = ''
                eniid=0
                for eni in instance['NetworkInterfaces']:
                    if 'Ipv6Address' in eni:
                        ipv6id=0
                        for ipv6 in eni['Ipv6Addresses']:
                            if ipv6id == 0:
                                MIPv6 = ipv6['Ipv6Address']
                            else:
                                PubIPV6[ipv6id] = ipv6['Ipv6Address']
                        ipv6id=ipv6id+1 
                    else:
                        MIPv6 =''
                    if 'PrivateIpAddresses' in eni:
                        ipv4id=0
                        for ipv4 in eni['PrivateIpAddresses']:
                            if MPrivIP != ipv4['PrivateIpAddress']:
                                PrivIPV4[ipv4id] = ipv4['PrivateIpAddress']
                            if 'Association' in ipv4:
                                if MPubIP != ipv4['Association']['PublicIp']:
                                    PubIPV4[ipv4id] = ipv4['Association']['PublicIp']
                        ipv4id=ipv4id+1 
        return hostname, MPrivIP, MPubIP, MIPv6, PubIPV6, PrivIPV4, PubIPV4, hostedzones
    except Exception as e:
        logger.error('ERROR: {}'.format(e))
        traceback.print_exc()
        return str(e)
